<?php

require_once './vendor/autoload.php';

use Symfony\Component\HttpFoundation\Request;
//use Symfony\Component\HttpFoundation\Response;
use Demo\Kernel;

//use Symfony\Component\HttpKernel\HttpKernelInterface;



$request = Request::createFromGlobals();


$kernel = new Kernel();
$response = $kernel->handle( $request );

//$response->setContent('Hello World');
$response->send();