<?php

require_once './vendor/autoload.php';

use Demo\Database;


//$db = Database::getInstance();


class Installer{



  public function install(){

    $this
      ->createTables()
      ->insertData()
      ;
  }



  public function update(){

  }



  public function createTables(){

    $db = Database::getInstance();

    $db->exec('CREATE TABLE `demo`.`user` ( `uid` INT NOT NULL AUTO_INCREMENT , `email` VARCHAR(255) NOT NULL , `name` VARCHAR(255) NOT NULL , `status` INT NOT NULL , `password` VARCHAR(32) NOT NULL , `created` DATETIME NOT NULL , `updated` DATETIME NOT NULL , `last_login` DATETIME NULL , PRIMARY KEY (`uid`), UNIQUE `email` (`email`)) ENGINE = InnoDB;');
    $db->exec('CREATE TABLE `demo`.`role` ( `rid` VARCHAR(64) NOT NULL , `name` VARCHAR(255) NOT NULL , PRIMARY KEY (`rid`)) ENGINE = InnoDB;');
    $db->exec('CREATE TABLE `demo`.`user_roles` ( `uid` INT NOT NULL , `rid` VARCHAR(64) NOT NULL ) ENGINE = InnoDB;');
    $db->exec('CREATE TABLE `demo`.`todo` ( `id` INT NOT NULL AUTO_INCREMENT , `title` VARCHAR(255) NOT NULL , `uid` INT NOT NULL , `state` INT NOT NULL , `created` DATETIME NOT NULL , `updated` DATETIME NOT NULL , `body` TEXT NOT NULL , PRIMARY KEY (`id`), INDEX `uid` (`uid`)) ENGINE = InnoDB;');


    return $this;
  }



  public function insertData(){

    $db = Database::getInstance();
    // add roles

    // add user 1

    $db->exec("INSERT INTO `role` (`rid`, `name`) VALUES ('anonymous', 'Anonymous'), ('authenticated', 'Authenticated') , ('admin', 'Admin') ;");

    $pass = md5('pass');

    $date = new \DateTime();
    $now = $date->format('Y-m-d H:i:s');

    $db->exec("INSERT INTO `user` (`uid`, `email`, `name`, `status`, `password`, `created`, `updated`, `last_login`) VALUES (NULL, 'admin@test.com', 'admin', '1', '$pass', '$now', '$now', NULL);");
    $uid = $db->lastInsertId();
    $db->exec("INSERT INTO `user_roles` (`uid`, `rid`) VALUES ($uid, 'authenticated') , ($uid, 'admin') ;");

    return $this;
  }


}

$installer = new Installer();
$installer->install();
//$installer->insertData();

/**
 *
 * create tables
 *
 * add rows
 */



/*
install users table
uid
name
email
password
created
updated
last login

role table
rid
name

user_roles
id
uid
rid

install todo table
id
uid
title
state
created
updated

*/