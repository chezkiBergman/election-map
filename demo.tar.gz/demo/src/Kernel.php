<?php

namespace Demo;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\HttpKernelInterface;
use Symfony\Component\HttpFoundation\Session\Session;
//use Symfony\Component\HttpFoundation\Session\Storage\NativeSessionStorage;

class Kernel implements HttpKernelInterface{

  public function handle(
    Request $request,
    int $type = self::MAIN_REQUEST,
    bool $catch = true
  ){


    $method = $request->getMethod();
    $path = $request->getPathInfo();

    $routes = [
      '/' => 'IndexController::index',
      '/debug' => 'IndexController::debug',

      '/login' => 'LoginController::index',
      '/logout' => 'LoginController::logout',
      '/forget' => 'LoginController::forget',
      '/jwt' => 'LoginController::jwt',
      '/register' => 'RegisterController::index',
      '/tmp' => 'RegisterController::tmp',

      '/profile' => 'IndexController::profile',

      '/todos' => 'TodosController::index',
      '/todos/add' => 'TodosController::add',

      '/admin/users' => 'UsersController::index',
    ];

    // start session
    $session = new Session( );
    $session->setName('mysession9567');

    $session->start();

    if( $session->getBag('attributes')->has('uid') ){
      $uid = $session->getBag('attributes')->get('uid');
      if( $user = User::load($uid) ){
        //print_r($user);
        $request->attributes->set('current_user' , $user);
      }
    }

    // check if has uid in session
    // if has load the user into the request

    if( isset($routes[$path])){

      $c = explode('::' , $routes[$path] );
      $cName = '\\Demo\\controller\\' . $c[0];
      $cMethod = $c[1];
      $controller = new $cName( $request, $session );

      $response = $controller->{$cMethod}();

    } else {
      // mot found
      return new Response('Not found', 404 );
      //return $response;
    }

    $html = $this->renderPage( $request, $response, $session );
    $response->setContent($html);

    return $response;

  }

  protected function render($file , $vars ){

    $template = file_get_contents($file);

    foreach($vars as $name => $value) {
      $template = str_replace('{' . $name . '}', $value, $template);
    }

    return $template;
  }

  protected function resolveController(){
    // return controller instance
  }

  protected function renderPage( $request , $response , $session ){

    // render into a page template
    $content = $response->getContent();

    if( $user = $request->attributes->get('current_user' , false) ){
      $menu = '
      <p class="mt-2">Hello '. $user->getName() .'</p>
      <a class="nav-link" href="logout">Logout</a>
      <a class="nav-link" href="profile">Profile</a>
    ';
    } else {
      $menu = '
        <a class="nav-link" href="register">Register</a>
        <a class="nav-link" href="login">Login</a>
        <a class="nav-link" href="forget">Forget</a>
      ';
    }


    $messages = [];
    $types = $session->getFlashBag()->all();
    foreach ($types as $key => $items) {
      foreach ($items as $item) {
        $messages[] = "$key: $item";
      }
    }

    $flash =  '';
    if( count($messages) ){
      $flash = '<div>' . implode('<br/>' , $messages ) . '</div>';
    }


    $html = $this->render('./tpl/page.html' , ['content' => $content , 'user_menu' => $menu, 'flash' => $flash ]);

    return $html;
  }
}