<?php

class NotFoundController {

  public function index(){

  }


}