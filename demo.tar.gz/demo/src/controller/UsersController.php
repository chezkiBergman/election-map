<?php

namespace Demo\controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
//use Symfony\Component\HttpFoundation\Session\Session;
use Demo\Database;
use PDO;

class UsersController extends AbstractController {


  public function index(){


    /** @var \PDO */
    $db = Database::getInstance();

    $s = $db->prepare('select * from user');
    $s->execute(/* ['uid' => $uid ] */);
    $data = /* (array) */ $s->fetchAll();

    /* $s = $db->prepare('select * from user_roles where uid = :uid');
    $s->execute(['uid' => $uid ]);
    $data2 =  $s->fetchAll();
    $roles = [];
    foreach ( $data2 as $r ) {
      $roles[] = $r->rid;
    }

    $user = new User();
    $user = User::create($data);
    $user->setRoles($roles);


    return $user; */


    //$s = $db->prepare('select * from user');
    //$s->execute([/* 'uid' => $uid  */]);
    //$this->dump(get_class_methods($s));
    //$data = /* (array) */ $s->fetchAll();

    //$this->dump( $data );

    $html = '';
    foreach ($data as $item) {
      $html .= "
        <tr>
          <td>$item->uid</td>
          <td>$item->name</td>
          <td>$item->email</td>
          <td>$item->status</td>
          <td>$item->created</td>
          <td>$item->updated</td>
          <td>$item->last_login</td>

        </tr>
      ";
    }
    $content = $this->render('./tpl/users.html' , [
      'rows' => $html ,
      'headers' => "
        <tr>
          <td>uid</td>
          <td>name</td>
          <td>email</td>
          <td>status</td>
          <td>created</td>
          <td>updated</td>
          <td>last_login</td>
        </tr>
      ",
    ]);

    return new Response( $content, Response::HTTP_OK, ['content-type' => 'text/html'] );

  }



}