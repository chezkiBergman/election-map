<?php

namespace Demo\controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
//use Symfony\Component\HttpFoundation\Session\Session;


class IndexController extends AbstractController {


  public function index(){

    //$this->dump($this->request->attributes->get('current_user' , false));

    /** @var Symfony\Component\HttpFoundation\Request */
    $request  = $this->request;



    /* $this->dump(get_class_methods( $this->request) );
    $this->dump([
      $this->request->getUri(),
      $this->request->getUriForPath('/dadi'),
      $this->request->getRelativeUriForPath('doda'),
      $this->request->getRequestUri(),
      $this->request->getUserInfo(),
     ] ); */
    //$this->debug('sa');

    $response = new Response( '', Response::HTTP_OK, ['content-type' => 'text/html'] );
    $response->setContent('Hello World');

    return $response;

  }


  public function debug(){

    $this->session->set('v2' , 'well, v');
    $this->session->set('v3' , '3333333 33333');

    $response = new Response( '', Response::HTTP_OK, ['content-type' => 'text/html'] );
    $response->setContent('Hello World');

    return $response;

  }


  public function profile(){

    //$this->session->set('v2' , 'well, v');
    //$this->session->set('v3' , '3333333 33333');

    $response = new Response( '', Response::HTTP_OK, ['content-type' => 'text/html'] );
    $response->setContent('here profile');

    return $response;

  }


}