<?php

namespace Demo\controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
//use Symfony\Component\HttpFoundation\Session\Session;
use Demo\Database;
use PDO;


class TodosController extends AbstractController {


  public function index(){


    /** @var \PDO */
    $db = Database::getInstance();

    $s = $db->prepare('select * from todo');
    $s->execute([/* 'uid' => $uid  */]);
    //$this->dump(get_class_methods($s));
    $data = /* (array) */ $s->fetchAll();

    //$this->dump( $data );

    $html = '';
    foreach ($data as $item) {
      $html .= "
        <tr>
          <td>$item->id</td>
          <td>$item->title</td>
          <td>$item->body</td>
          <td>$item->state</td>

        </tr>
      ";
    }
    $content = $this->render('./tpl/todos.html' , [
      'rows' => $html ,
      'headers' => "<tr><td>id</td><td>title</td><td>body</td><td>state</td></tr>",
    ]);

    return new Response( $content, Response::HTTP_OK, ['content-type' => 'text/html'] );

  }

  public function add(){
    return new Response( 'here form', Response::HTTP_OK, ['content-type' => 'text/html'] );
  }



}