<?php

namespace Demo\controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Demo\User;
use Symfony\Component\HttpFoundation\Session\Session;
use Firebase\JWT\JWT;


class LoginController extends AbstractController{

  public function index(){

    $data = [
      'email' => '',
      'password' => '',
    ];

    if( $this->request->getMethod() == 'POST'){

      $email = $this->request->request->get('email');
      $password = $this->request->request->get('password');

      $data = [
        'email' => $email,
        'password' => $password,
      ];

      //check to see if we have this user
      $user = User::loadByEmail( $email );

      if( $user && $user->getPassword() == md5($password) ){

        $this->session->set('uid' , $user->id() );
        $this->session->migrate();
        return $this->redirect('/demo/');

      } else {
        // set messages to form
        $this->session->getFlashBag()->add('error' , 'email or password is incorrect.' );
      }

    }

    $content = $this->render('./tpl/login.html' , $data );

    return new Response($content , Response::HTTP_OK, ['content-type' => 'text/html'] );

  }


  public function logout(){
    $this->session->getBag('attributes')->remove('uid');
    $this->session->migrate(true);
    return $this->redirect('/demo');
  }


  public function forget(){

    $response = new Response( '', Response::HTTP_OK, ['content-type' => 'text/html'] );
    $response->setContent('here forget form');

    return $response;

  }

  public function jwt(){




    $key = "example_key";
    $payload = array(
        "iss" => "http://example.org",
        "aud" => "http://example.com",
        "iat" => 1356999524,
        "nbf" => 1357000000
    );

    /**
     * IMPORTANT:
     * You must specify supported algorithms for your application. See
     * https://tools.ietf.org/html/draft-ietf-jose-json-web-algorithms-40
     * for a list of spec-compliant algorithms.
     */
    $jwt = JWT::encode($payload, $key);
    $decoded = JWT::decode($jwt, $key, array('HS256'));

    print_r($decoded);


    $response = new Response( '', Response::HTTP_OK, ['content-type' => 'text/html'] );
    $response->setContent('here jwt form');

    return $response;

  }


}