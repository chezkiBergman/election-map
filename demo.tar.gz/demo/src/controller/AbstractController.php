<?php

namespace Demo\controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;



use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Session\Session;



abstract class AbstractController {

  protected $request;
  protected $session;

  public function __construct( Request $request, Session $session )
  {
    $this->request = $request;
    $this->session = $session;
    // init session
  }

  protected function render($file , $vars ){

    $template = file_get_contents($file);

    foreach($vars as $name => $value) {
      $template = str_replace('{' . $name . '}', $value, $template);
    }

    return $template;
  }


  public function redirect($url){
    //$response = new RedirectResponse('http://example.com/');
    $response = new RedirectResponse($url);
    return $response;
  }

  public function addMessage( $type , $body){

  }


  public function dump($a){
    echo '<pre>';
    print_r($a);
    echo '</pre>';
  }
}