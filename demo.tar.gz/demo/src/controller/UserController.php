<?php

namespace Demo\controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Demo\User;
use Symfony\Component\Validator\Validation;
use Symfony\Component\Validator\Constraints\Collection;

use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\Email;

class UserController extends AbstractController{

  public function register(){

    // show a from to register the user with name, email, password (twice)
    // show the form
    // validate and process the form

    // if method == post
    // validate th form
    // process the form

   /*  $u1 = User::load(1);

    echo '<pre>';
    print_r( $u1  );
    echo '</pre>'; */

    $date = new \DateTime();

    $data = [
      'name' => '',
      'email' => '',
      'password' => '',
      'password2' => '',
    ];

    if( $this->request->getMethod() == 'POST'){


      $data = $this->request->request->all();

      $validator = Validation::createValidator();

      $constraint = new Collection([
        'name'      => [ new Length(['min' => 4]), new NotBlank() ],
        'email'     => [ new Email(), new NotBlank() ],
        'password'  => [ new Length(['min' => 4]), new NotBlank() ],
        'password2' => [ new Length(['min' => 4]), new NotBlank() ],
      ]);

      $violations = $validator->validate($data, $constraint);

      if( count($violations)  == 0 ){


        $data['password'] = User::hashPassword( $data['password'] );

        $user = User::create( $data );
        $user->setRoles(['authenticated']);
        $user->setStatus(1);
        $user->save();

        $this->session->getFlashBag()->add('info' , 'user created. please login');

        return $this->redirect('/demo/login');

      } else {
        foreach ($violations as $violation) {
          //$this->dump( $violation->getMessage());
          $this->session->getFlashBag()->add('error' ,$violation->getMessage());
        }
      }

    }

    $content = $this->render('./tpl/register.html' , $data );

    $response = new Response( '', Response::HTTP_OK, ['content-type' => 'text/html'] );
    $response->setContent($content);

    return $response;

  }


  public function login(){

    $data = [
      'email' => '',
      'password' => '',
    ];

    if( $this->request->getMethod() == 'POST'){

      $email = $this->request->request->get('email');
      $password = $this->request->request->get('password');

      $data = [
        'email' => $email,
        'password' => $password,
      ];

      //check to see if we have this user
      $user = User::loadByEmail( $email );

      if( $user && $user->getPassword() == md5($password) ){

        $this->session->set('uid' , $user->id() );
        $this->session->migrate();
        return $this->redirect('/demo/');

      } else {
        // set messages to form
        $this->session->getFlashBag()->add('error' , 'email or password is incorrect.' );
      }

    }

    $content = $this->render('./tpl/login.html' , $data );

    return new Response($content , Response::HTTP_OK, ['content-type' => 'text/html'] );

  }


  public function logout(){
    $this->session->getBag('attributes')->remove('uid');
    $this->session->migrate(true);
    return $this->redirect('/demo');
  }


  public function forget(){

    $response = new Response( '', Response::HTTP_OK, ['content-type' => 'text/html'] );
    $response->setContent('here forget form');

    return $response;

  }

  public function jwt(){




    $key = "example_key";
    $payload = array(
        "iss" => "http://example.org",
        "aud" => "http://example.com",
        "iat" => 1356999524,
        "nbf" => 1357000000
    );

    /**
     * IMPORTANT:
     * You must specify supported algorithms for your application. See
     * https://tools.ietf.org/html/draft-ietf-jose-json-web-algorithms-40
     * for a list of spec-compliant algorithms.
     */
    $jwt = JWT::encode($payload, $key);
    $decoded = JWT::decode($jwt, $key, array('HS256'));

    print_r($decoded);


    $response = new Response( '', Response::HTTP_OK, ['content-type' => 'text/html'] );
    $response->setContent('here jwt form');

    return $response;

  }


  public function tmp(){

    $validator = Validation::createValidator();

    $constraint = new Collection([
      'name' => [
        new Length(['min' => 4]),
        new NotBlank(),
      ],

      'email' => [ new Email(), new NotBlank() ],
      'password' => [ new Email(), new NotBlank() ],
      'password2' => [ new Email(), new NotBlank() ],

    ]);

    $input = [];

    $violations = $validator->validate($input, $constraint);
    $this->dump( $violations  );

    foreach ($violations as $violation) {
      $this->dump( $violation->getMessage());
    }

    $response = new Response( '', Response::HTTP_OK, ['content-type' => 'text/html'] );

  }



}