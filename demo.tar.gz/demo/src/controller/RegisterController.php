<?php

namespace Demo\controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Demo\User;
use Symfony\Component\Validator\Validation;
use Symfony\Component\Validator\Constraints\Collection;

use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\Email;




class RegisterController extends AbstractController{

  public function index(){

    // show a from to register the user with name, email, password (twice)
    // show the form
    // validate and process the form

    // if method == post
    // validate th form
    // process the form

   /*  $u1 = User::load(1);

    echo '<pre>';
    print_r( $u1  );
    echo '</pre>'; */

    $date = new \DateTime();

    $data = [
      'name' => '',
      'email' => '',
      'password' => '',
      'password2' => '',
    ];

    if( $this->request->getMethod() == 'POST'){


      $data = $this->request->request->all();

      $validator = Validation::createValidator();

      $constraint = new Collection([
        'name'      => [ new Length(['min' => 4]), new NotBlank() ],
        'email'     => [ new Email(), new NotBlank() ],
        'password'  => [ new Length(['min' => 4]), new NotBlank() ],
        'password2' => [ new Length(['min' => 4]), new NotBlank() ],
      ]);

      $violations = $validator->validate($data, $constraint);

      if( count($violations)  == 0 ){


        $data['password'] = User::hashPassword( $data['password'] );

        $user = User::create( $data );
        $user->setRoles(['authenticated']);
        $user->setStatus(1);
        $user->save();

        $this->session->getFlashBag()->add('info' , 'user created. please login');

        return $this->redirect('/demo/login');

      } else {
        foreach ($violations as $violation) {
          //$this->dump( $violation->getMessage());
          $this->session->getFlashBag()->add('error' ,$violation->getMessage());
        }
      }

    }

    $content = $this->render('./tpl/register.html' , $data );

    $response = new Response( '', Response::HTTP_OK, ['content-type' => 'text/html'] );
    $response->setContent($content);

    return $response;

  }

  public function tmp(){

    $validator = Validation::createValidator();

    $constraint = new Collection([
      'name' => [
        new Length(['min' => 4]),
        new NotBlank(),
      ],

      'email' => [ new Email(), new NotBlank() ],
      'password' => [ new Email(), new NotBlank() ],
      'password2' => [ new Email(), new NotBlank() ],

    ]);

  //

  $input = [];

  $violations = $validator->validate($input, $constraint);
  $this->dump( $violations  );

  foreach ($violations as $violation) {
    $this->dump( $violation->getMessage());
}

  $response = new Response( '', Response::HTTP_OK, ['content-type' => 'text/html'] );

  }

}