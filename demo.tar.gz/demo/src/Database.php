<?php

namespace Demo;

class Database extends \PDO{

  protected static $instance = null;

  protected function __construct($host,  $username,  $password ,  $database ){

    try {
      parent::__construct( "mysql:host=$host;dbname=$database", $username,  $password );
      $this->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
      $this->setAttribute(\PDO::ATTR_DEFAULT_FETCH_MODE, \PDO::FETCH_OBJ);
    }
    catch(\PDOException $e)
    {
      echo "Connection failed: " . $e->getMessage();
      die();
    }

  }

  public static function getInstance(){


    $host = "database";
    $username = "lamp";
    $password = "lamp";
    $database = "demo";


    if (self::$instance == null){
      self::$instance = new Database($host,  $username,  $password ,  $database);
    }

    return self::$instance;

  }

}