<?php

namespace Demo;

use Demo\Database;
use PDO;

class User{

  protected $uid;
  protected $email;
  protected $name;
  protected $roles = ['anonymous'];
  protected $password;

  protected $status = 0;

  protected $created;
  protected $updated;
  protected $last_login;


  public static function create( array $props ){

    $user = new User();

    foreach ($props as $k => $v) {

      switch ($k) {
        case 'email': $user->setEmail($v); break;
        case 'name':  $user->setName($v);  break;
        case 'uid': $user->setId($v);  break;
        case 'id':  $user->setId($v);  break;
        case 'status': $user->setStatus($v); break;
        case 'password':  $user->setPassword($v); break;
        case 'roles': $user->setRoles($v); break;
        case 'created': $user->setCreated($v); break;
        case 'updated': $user->setUpdated($v); break;
        case 'last_login': $user->setLastLogin($v); break;
        default: break;
      }
      # code...
    }

    return $user;
  }

  public static function load( $uid ){


    /** @var \PDO */
    $db = Database::getInstance();

    $s = $db->prepare('select * from user where uid = :uid');
    $s->execute(['uid' => $uid ]);
    $data = (array) $s->fetch();

    $s = $db->prepare('select * from user_roles where uid = :uid');
    $s->execute(['uid' => $uid ]);
    $data2 =  $s->fetchAll();
    $roles = [];
    foreach ( $data2 as $r ) {
      $roles[] = $r->rid;
    }

    $user = new User();
    $user = User::create($data);
    $user->setRoles($roles);


    return $user;
  }


  public static function loadByEmail( $email ){



    /** @var \PDO */
    $db = Database::getInstance();

    $s = $db->prepare('select uid from user where email = :email');
    $s->execute(['email' => $email ]);
    $data = $s->fetch();

    if( $data ){

      $uid = $data->uid;

      return User::load($uid);

    }

    return false;


  }


  public function id(){
    return $this->uid;
  }

  public function getEmail(){
    return $this->email;
  }

  public function getName(){
    return $this->name;
  }

  public function getStatus(){
    return $this->status;
  }

  public function getRoles(){
    return $this->roles;
  }


  public function getPassword(){
    return $this->password;
  }


  public function setEmail($email){
    $this->email = $email;
    return $this;
  }

  public function setName($name){
    $this->name = $name;
    return $this;
  }

  public function setId($id){
    $this->uid = $id;
    return $this;
  }

  public function setStatus($status){
    $this->status = $status;
    return $this;
  }

  public function setPassword($password){
    $this->password = $password;
    return $this;
  }

  public static function hashPassword( $password ){
    return md5( $password );
  }

  public function setRoles(array $roles){
    $this->roles = $roles;
    return $this;
  }

  public function addRole( $role ){
    $this->roles[] = $role;
    return $this;
  }


  public function setCreated($created){
    $this->created = $created;
    return $this;
  }


  public function setUpdated($updated){
    $this->updated = $updated;
    return $this;
  }

  public function setLastLogin($datetime){
    $this->last_login = $datetime;
    return $this;
  }


  public function save(){


    // go over roles and put

    if( $this->uid  ){
      $this->update();
    } else {
      $this->insert();
    }

  }


  protected function insert(){

    /** @var \PDO */
    $db = Database::getInstance();

    // "INSERT INTO `user` (`uid`, `email`, `name`, `status`, `password`, `created`, `updated`, `last_login`) VALUES (NULL, 'aa', 'bb', '4', 'abc', '2021-09-06', '2021-09-16', '2021-09-23');"

    $date = new \DateTime();

    $now = $date->format('Y-m-d H:i:s');

    $params = [
      'email' => $this->getEmail(),
      'name' => $this->getName(),
      'status' => $this->getStatus(),
      'password' => $this->getPassword(),
      'created' => $now,
      'updated' => $now,
    ];

    $db
      ->prepare("INSERT INTO `user` (`uid`, `email`, `name`, `status`, `password`, `created`, `updated`, `last_login`) VALUES (NULL, :email, :name, :status, :password, :created, :updated, NULL);")
      ->execute($params )
      ;

    $uid = $db->lastInsertId();
    $this->setId($uid);

    $s = $db->prepare("INSERT INTO `user_roles` (`uid`, `rid`) VALUES (:uid, :rid);");

    foreach ($this->roles as $v ) {
      $s->execute([
        'uid' => $uid,
        'rid' => $v
      ]);
    }
  }

  protected function update(){

  }



  public function validate(){

    // check email
    // check name
    // check password

    return true;

  }





}