so demo for autontication etc .

so using symphony HttpKernel and HttpFoundation component


install.php  - install db
index.php  - main entry point

routes
/register
/login
/logout
/forget
/users
/usr/id

/resources
/resource/id

/index



simple templating
bootstrap


then create jwt
and autonticate with jwt

maybe build small react app

todo:
settings
flash messagfes
+change name of session
regenrate session id on login, logout etc.
base url replacments
json endpoint fot data
simple react app
jwt autontication


